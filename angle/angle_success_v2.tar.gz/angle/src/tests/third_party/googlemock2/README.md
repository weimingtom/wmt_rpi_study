# googlemock

This project has been absorbed into the [GoogleTest](http://github.com/google/googletest) project.
All open googlemock issues have been moved there.
