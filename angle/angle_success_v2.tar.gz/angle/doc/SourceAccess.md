# ANGLE Source Code

# Browsing

ANGLE's source no longer resides at code.google.com! To browse the ANGLE source,
please visit https://chromium.googlesource.com/angle/angle

# Checkout

You may clone the ANGLE repository with:

> `git clone https://chromium.googlesource.com/angle/angle`

For full instructions on setting up your system with the necessary prerequisites
for development with ANGLE, please see the DevSetup page.
